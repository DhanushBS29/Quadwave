﻿using System;

namespace CustomerManagementSystemApi.Dto
{
    public class CustomerUpdateDto
    {
        public string FirstName { set; get; }
        public string LastName { set; get; }
    
        public DateTime CreatedDate { set; get; }
    }
}
