﻿using System;

namespace CustomerManagementSystemApi.Dto
{
    public class CustomerReadDto
    {
        public int CustomerId { set; get; }
        public string FirstName { set; get; }
        public string LastName { set; get; }
        //public string Address { set; get; }
        public DateTime CreatedDate { set; get; }

    }
}
