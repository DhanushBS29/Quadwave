﻿namespace CustomerManagementSystemApi.Dto
{
    public class CustomerDeleteDto
    {
    }
}
