﻿namespace CustomerManagementSystemApi.Dto
{
    public class AddressDeleteDto
    {
    }
}
