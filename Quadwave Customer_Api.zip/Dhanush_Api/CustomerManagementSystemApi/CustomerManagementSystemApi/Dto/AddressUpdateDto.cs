﻿namespace CustomerManagementSystemApi.Dto
{
    public class AddressUpdateDto
    {
       
        public string Country { set; get; }
        public string City { set; get; }
        public string StreetAddress { set; get; }
        public string Phone { set; get; }
    }
}
