﻿using AutoMapper;
using CustomerManagementSystemApi.Dto;
using CustomerManagementSystemApi.Models;

namespace CustomerManagementSystemApi.Profiles
{
    public class CustomerProfile : Profile
    {
        public CustomerProfile()
        {
   
        CreateMap<Customer,CustomerReadDto > ();
            CreateMap<CustomerCreateDto, Customer>();
            CreateMap< CustomerUpdateDto, Customer>();
            CreateMap<CustomerDeleteDto, Customer>();

            CreateMap<CustomerAddress,AddressReadDto >();
            CreateMap<AddressCreateDto, CustomerAddress>();
            CreateMap<AddressUpdateDto, CustomerAddress>();
            CreateMap<AddressDeleteDto, CustomerAddress>();
        }
    }
}
