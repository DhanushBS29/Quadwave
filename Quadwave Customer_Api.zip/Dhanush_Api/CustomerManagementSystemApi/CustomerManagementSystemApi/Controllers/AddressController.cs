﻿using AutoMapper;
using CustomerManagementSystemApi.Data;
using CustomerManagementSystemApi.Dto;
using CustomerManagementSystemApi.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace CustomerManagementSystemApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AddressController : ControllerBase
    {
        private readonly ICustomerInfo _info;
        private readonly IMapper _mapper;

        public AddressController(ICustomerInfo info, IMapper mapper)
        {
            _info = info;
            _mapper = mapper;

        }
        
       
        [HttpGet]
        public ActionResult<IEnumerable<AddressReadDto>> GetAddress()
        {
            var addr = _info.GetAddress();
            return Ok(_mapper.Map<IEnumerable<AddressReadDto>>(addr));
        }
        [HttpPost]
        public ActionResult<AddressCreateDto> CreateAddress(AddressCreateDto addressCreateDto)
        {
            if (addressCreateDto != null)
            {
                var newAdd = _mapper.Map<CustomerAddress>(addressCreateDto);
                _info.CreateAddress(newAdd);
                return Ok(addressCreateDto);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpDelete("{Id}")]
        public ActionResult DeleteAddress(AddressDeleteDto addressDeleteDto, int Id)
        {
            var empInDb = _info.GetAddress(Id);
            if (empInDb != null)
            {
                _mapper.Map(addressDeleteDto, empInDb);
                _info.DeleteAddress(empInDb);
                return Ok();

            }
            return NotFound();
        }
        [HttpPut("{Id}")]
        public ActionResult UpdateAddress(AddressUpdateDto addressUpdateDto, int Id)
        {
            var empInDb = _info.GetAddress(Id);
            if (empInDb != null)
            {
                _mapper.Map(addressUpdateDto, empInDb);
                _info.UpdateAddress(empInDb);
                return Ok();

            }
            else
            {
                return NotFound();
            }

        }
         [HttpGet("{Id}")]
        public ActionResult<AddressReadDto>GetAddressById(int Id)
        {
            var cust = _info.GetAddress(Id);
            return Ok(_mapper.Map<AddressReadDto>(cust));

        }

    }
}
