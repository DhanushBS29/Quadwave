﻿using AutoMapper;
using CustomerManagementSystemApi.Data;
using CustomerManagementSystemApi.Dto;
using CustomerManagementSystemApi.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections;
using System.Collections.Generic;

namespace CustomerManagementSystemApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerInfo _info;
        private readonly IMapper _mapper;

        public CustomerController(ICustomerInfo info, IMapper mapper)
        {
            _info = info;
            _mapper = mapper;

        }
        [HttpGet("{Id}")]
        public ActionResult<CustomerReadDto>GetCustomerById(int Id)
        {
            var cust = _info.GetCustomer(Id);
            return Ok(_mapper.Map<CustomerReadDto>(cust));

        }
        [HttpGet]
        public ActionResult<IEnumerable<CustomerReadDto>> GetCustomer()
        {
            var customer = _info.GetCustomers();
            return Ok(_mapper.Map<IEnumerable<CustomerReadDto>>(customer));
        }
        [HttpPut("{Id}")]
        public ActionResult UpdateCustomer(CustomerUpdateDto customerUpdateDto,int Id)
        {
            var empInDb = _info.GetCustomer(Id);
            if (empInDb != null)
            {
                _mapper.Map(customerUpdateDto, empInDb);
                _info.UpdateCustomer(empInDb);
                return Ok();

            }
            else
            {
                return NotFound();
            }

        }
        [HttpDelete("{Id}")]
        public ActionResult DeleteCust(CustomerDeleteDto customerDeleteDto,int Id)
        {
            var empInDb = _info.GetCustomer(Id);
            if (empInDb != null)
            {
                _mapper.Map(customerDeleteDto, empInDb);
                _info.DeleteCustomer(empInDb);
                return Ok();

            }
            return NotFound();
        }
        [HttpPost]
        public ActionResult<CustomerReadDto> CreateCustomer(CustomerCreateDto customerCreateDto)
        {
            if (customerCreateDto != null)
            {
                var newCust = _mapper.Map<Customer>(customerCreateDto);
                _info.CreateCustomer(newCust);
                return Ok(customerCreateDto);
            }
            else
            {
                return NotFound();
            }
        }


    }
}
