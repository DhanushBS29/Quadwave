﻿using CustomerManagementSystemApi.Models;
using Microsoft.EntityFrameworkCore;

namespace CustomerManagementSystemApi.Data
{
    public class CustomerContext:DbContext
    {
        public CustomerContext(DbContextOptions<CustomerContext> opt) : base(opt)
        {

        }
        public DbSet<Customer> CustomerDetails { set; get; }
        public DbSet<CustomerAddress> CustomerAddresseDetailes { set; get; }
    }
}
