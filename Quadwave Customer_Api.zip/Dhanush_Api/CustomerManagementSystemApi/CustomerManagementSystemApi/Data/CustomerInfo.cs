﻿using CustomerManagementSystemApi.Models;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace CustomerManagementSystemApi.Data
{
    public class CustomerInfo : ICustomerInfo
    {
        private readonly CustomerContext _context;

        public CustomerInfo(CustomerContext context)
        {
            _context = context;
        }

        public void DeleteCustomer(Customer c)
        {
            _context.Remove(c);
            _context.SaveChanges();
        }

        public Customer GetCustomer(int id)
        {
            var customer = _context.CustomerDetails.SingleOrDefault(m => m.CustomerId == id);
            return customer;
        }

        public List<Customer> GetCustomers()
        {
            var customer = _context.CustomerDetails.ToList();
            return customer;
        }

        public void UpdateCustomer(Customer c)
        {
            //  _context.CustomerDetail.Add(c);
            _context.SaveChanges();
        }
        public Customer CreateCustomer(Customer c)
        {
            _context.CustomerDetails.Add(c);
            _context.SaveChanges();
            return c;
        }
        
        

        public List<CustomerAddress> GetAddress()
        {
            var customer = _context.CustomerAddresseDetailes.ToList();
            return customer;
        }

        public CustomerAddress CreateAddress(CustomerAddress c)
        {
            _context.CustomerAddresseDetailes.Add(c);
            _context.SaveChanges();
            return c;

        }

        public void UpdateAddress(CustomerAddress c)
        {
            _context.SaveChanges();
        }

        public void DeleteAddress(CustomerAddress c)
        {
            _context.Remove(c);
            _context.SaveChanges();
        }

        public CustomerAddress GetAddress(int id)
        {
            var customer = _context.CustomerAddresseDetailes.SingleOrDefault(m=>m.Id==id);
            return customer;

        }
    }
    }
    

