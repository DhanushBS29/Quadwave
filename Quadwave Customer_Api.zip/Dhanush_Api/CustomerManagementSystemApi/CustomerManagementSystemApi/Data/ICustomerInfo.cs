﻿using CustomerManagementSystemApi.Models;
using System.Collections.Generic;

namespace CustomerManagementSystemApi.Data
{
    public interface ICustomerInfo
    {
        public Customer GetCustomer(int id);
        public List<Customer> GetCustomers();
        public List<CustomerAddress> GetAddress();
          public Customer CreateCustomer(Customer c);
          void UpdateCustomer(Customer c);
          void DeleteCustomer(Customer c);
        public CustomerAddress CreateAddress(CustomerAddress c);
        public void UpdateAddress(CustomerAddress c);
        public void DeleteAddress(CustomerAddress c);
        public CustomerAddress GetAddress(int id);
    }
}
