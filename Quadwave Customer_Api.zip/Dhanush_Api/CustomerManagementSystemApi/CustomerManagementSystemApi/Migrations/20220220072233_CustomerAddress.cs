﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CustomerManagementSystemApi.Migrations
{
    public partial class CustomerAddress : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("insert into CustomerAddresseDetailes values(13,'India','Mysore','Kuvempunagar','8660196990')");

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
