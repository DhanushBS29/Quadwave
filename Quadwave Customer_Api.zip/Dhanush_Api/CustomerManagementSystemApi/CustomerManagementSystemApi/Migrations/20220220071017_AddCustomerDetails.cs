﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CustomerManagementSystemApi.Migrations
{
    public partial class AddCustomerDetails : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("insert into CustomerDetails values('Dhanush','B S','12/2/2022 1:39:05')");
            migrationBuilder.Sql("insert into CustomerDetails values('Ajith','K R','12/1/2022 1:39:05')");
            migrationBuilder.Sql("insert into CustomerDetails values('Hemanth','Kumar','2/2/2022 1:39:05')");

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
